# TaskSpark — Project Log

Running log of daily progress for the AB Talks 60-Day Claude AI Challenge capstone.

---

## Day 1 — Requirements
- Discovered the project idea through a guided interview: an AI-powered tool that extracts tasks + due dates from messy pasted text (notes, emails, chat).
- Locked v1.0 scope: plain text input only, no accounts, no database, no saved history.
- Deliverables produced: PRD, Implementation Blueprint (Days 2–10), Pitch Deck.
- Status: ✅ Complete.

## Day 2 — System Design
- Created standalone public GitHub repository: `Nidhisingh0z/taskspark`.
- Cloned locally to `D:\claude\taskspark` and created the initial project structure.
- Finalized the tech stack (at the time: Claude API, no database, no auth, Vercel hosting).
- Designed and documented full system architecture, data schema rationale, API contract, UI wireframes, and project structure.
- Status: ✅ Complete.

## Day 3 — Project Setup & Foundation
- Verified development environment: Node.js v24.19.0, npm 11.17.0, Git 2.53.0 (all pre-installed), Vercel CLI 59.1.4 (newly installed).
- Initialized the project: `npm init -y`, installed dependencies.
- **AI provider changed from Anthropic Claude to Google Gemini** (`@google/genai`, model `gemini-3.5-flash-lite`) — builder decision, using an already-available Google API key. Flagged for possible AB Talks Claude Challenge eligibility impact.
- Discovered and fixed a Day 2 issue: `index.html`, `style.css`, `script.js`, and `api/` were missing from disk due to a PowerShell/cmd command mismatch; recreated and verified.
- Built and tested a minimal end-to-end "Hello World" pipeline locally via `vercel dev` — confirmed working: browser → serverless function → Gemini API → browser.
- Updated `ARCHITECTURE.md` to reflect the Gemini provider change.
- New docs: `SETUP.md`, `ENVIRONMENT.md`, `DAY3-SUMMARY.md`, Day 3 blueprint addendum.
- Status: ✅ Complete.

## Day 4 — (Not yet started)
- Planned: Core UI Build (full styled interface for all 5 states: Empty, Loading, Results, No-Tasks-Found, Error).

---

*This log is updated at the end of each day and lives in the `docs/` folder alongside the PRD, Implementation Blueprint, and design docs.*
